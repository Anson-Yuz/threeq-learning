'use strict';

const { BookingRepository } = require('./bookingRepository');
const { BOOKING_STATUS } = require('../domain/constants');

function firstRow(result) {
  const rows = Array.isArray(result) ? result[0] : result;
  return Array.isArray(rows) && rows.length ? rows[0] : null;
}

class CancellationRepository extends BookingRepository {
  async findBookingLocator(bookingId) {
    return firstRow(await this.pool.execute(
      `SELECT id, session_id, user_id, status
       FROM bookings
       WHERE id = ?
       LIMIT 1`,
      [bookingId]
    ));
  }

  async lockBooking(bookingId, connection) {
    return firstRow(await connection.execute(
      `SELECT id, session_id, user_id, status, source, created_at,
              cancelled_at, cancel_reason, operator_user_id
       FROM bookings
       WHERE id = ?
       LIMIT 1
       FOR UPDATE`,
      [bookingId]
    ));
  }

  async cancelConfirmedBooking({ bookingId, userId, cancelledAt }, connection) {
    const [result] = await connection.execute(
      `UPDATE bookings
       SET status = 'cancelled',
           cancelled_at = ?,
           cancel_reason = NULL,
           operator_user_id = NULL
       WHERE id = ? AND user_id = ? AND status = 'confirmed'`,
      [cancelledAt, bookingId, userId]
    );
    return result.affectedRows === 1;
  }

  async cancelFormedSessionForInsufficientStudents(sessionId, cancelledAt, connection) {
    const [result] = await connection.execute(
      `UPDATE class_sessions
       SET lifecycle_status = 'cancelled',
           formation_status = 'failed',
           formation_decided_at = ?,
           cancel_reason = 'insufficient_students',
           cancelled_at = ?,
           booked_count = 0,
           version = version + 1
       WHERE id = ?
         AND lifecycle_status = 'open'
         AND formation_status = 'formed'`,
      [cancelledAt, cancelledAt, sessionId]
    );
    return result.affectedRows === 1;
  }

  async countBookingStatus(sessionId, status, connection) {
    const row = firstRow(await connection.execute(
      `SELECT COUNT(*) AS count_value
       FROM bookings
       WHERE session_id = ? AND status = ?`,
      [sessionId, status]
    ));
    return Number(row ? row.count_value : 0);
  }
}

module.exports = Object.freeze({ CancellationRepository });
