'use strict';

const { createFormationWorkerModule } = require('../bootstrap/createFormationWorkerModule');

async function main() {
  const batchSize = process.env.FORMATION_BATCH_SIZE === undefined || process.env.FORMATION_BATCH_SIZE === ''
    ? undefined
    : Number(process.env.FORMATION_BATCH_SIZE);
  const moduleInstance = createFormationWorkerModule({ batchSize });

  try {
    const result = await moduleInstance.formationJob.runOnce();
    process.stdout.write(`${JSON.stringify(result)}\n`);
    if (result.errorCount > 0) process.exitCode = 1;
  } finally {
    if (moduleInstance.pool && typeof moduleInstance.pool.end === 'function') {
      await moduleInstance.pool.end();
    }
  }
}

if (require.main === module) {
  main().catch((error) => {
    process.stderr.write(`${error && error.stack ? error.stack : String(error)}\n`);
    process.exitCode = 1;
  });
}

module.exports = Object.freeze({ main });
