'use strict';

const { createDatabasePool } = require('../db/pool');
const { FormationWorkerRepository } = require('../booking/formationWorkerRepository');
const { FormationService } = require('../booking/formationService');
const { FormationWorker } = require('../jobs/formationWorker');
const { FormationJob } = require('../jobs/formationJob');

function createFormationWorkerModule({
  env = process.env,
  pool = null,
  nowDate = () => new Date(),
  batchSize = undefined
} = {}) {
  const databasePool = pool || createDatabasePool({ env });
  const repository = new FormationWorkerRepository({ pool: databasePool });
  const formationService = new FormationService({ repository });
  const worker = new FormationWorker({
    repository,
    formationService,
    now: nowDate,
    ...(batchSize === undefined ? {} : { batchSize })
  });
  const job = new FormationJob({ worker });

  return Object.freeze({
    pool: databasePool,
    formationWorkerRepository: repository,
    formationService,
    formationWorker: worker,
    formationJob: job
  });
}

module.exports = Object.freeze({ createFormationWorkerModule });
