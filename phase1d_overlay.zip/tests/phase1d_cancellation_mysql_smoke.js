'use strict';

const mysql = require('mysql2/promise');
const { CancellationRepository } = require('../backend/booking/cancellationRepository');
const { FormationService } = require('../backend/booking/formationService');
const { CancellationService } = require('../backend/booking/cancellationService');
const { BookingService } = require('../backend/booking/bookingService');
const { withTransaction } = require('../backend/db/pool');

let passCount = 0;
let failCount = 0;
function pass(label) { passCount += 1; console.log(`PASS | ${label}`); }
function fail(label, detail = '') { failCount += 1; console.error(`FAIL | ${label}${detail ? ` | ${detail}` : ''}`); }
function assertCheck(condition, label, detail = '') { if (condition) pass(label); else fail(label, detail); }

function mysqlDate(value) {
  const d = value instanceof Date ? value : new Date(value);
  return d.toISOString().slice(0, 23).replace('T', ' ');
}
function plusMinutes(value, minutes) { return new Date(new Date(value).getTime() + minutes * 60_000); }
function auth(userId) { return { user: { id: userId, status: 'active' }, roles: ['student'], teacher: null }; }
function resultCode(settled) { return settled.status === 'rejected' && settled.reason ? settled.reason.code : null; }
async function count(pool, sql, params = []) { const [rows] = await pool.execute(sql, params); return Number(Object.values(rows[0])[0]); }
async function row(pool, sql, params = []) { const [rows] = await pool.execute(sql, params); return rows[0] || null; }

async function main() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: process.env.DB_NAME || 'hubeier_phase1d_smoke',
    timezone: 'Z', charset: 'utf8mb4', waitForConnections: true, connectionLimit: 30, dateStrings: false
  });

  try {
    const [versionRows] = await pool.execute('SELECT VERSION() AS version, @@transaction_isolation AS isolation');
    console.log(`MYSQL_VERSION=${versionRows[0].version}`);
    console.log(`TRANSACTION_ISOLATION=${versionRows[0].isolation}`);
    assertCheck(/^8\./.test(versionRows[0].version), 'real MySQL 8.x instance is running');
    assertCheck(String(versionRows[0].isolation).toUpperCase().includes('REPEATABLE'), 'cancellation concurrency test runs under REPEATABLE READ');

    await pool.execute(`INSERT INTO users (id, openid, real_name, status) VALUES (9200, 'phase1d-teacher', 'Phase1D Teacher', 'active')`);
    await pool.execute(`INSERT INTO user_roles (user_id, role_code) VALUES (9200, 'teacher')`);
    await pool.execute(`INSERT INTO teachers (id, user_id, name, status) VALUES (9200, 9200, 'Phase1D Teacher', 'active')`);
    await pool.execute(`INSERT INTO courses (id, name, enabled) VALUES (9200, 'Phase1D Course', 1)`);
    for (let id = 2001; id <= 2080; id += 1) {
      await pool.execute(`INSERT INTO users (id, openid, real_name, status) VALUES (?, ?, ?, 'active')`, [id, `phase1d-student-${id}`, `Student ${id}`]);
      await pool.execute(`INSERT INTO user_roles (user_id, role_code) VALUES (?, 'student')`, [id]);
    }

    async function createSession({
      id, startAt = '2026-09-10T11:00:00.000Z', classTypeId = 1,
      lifecycle = 'open', formation = 'pending', bookedCount = 0,
      cancelReason = null, cancelledAt = null
    }) {
      const type = classTypeId === 1 ? { min: 3, capacity: 18 } : classTypeId === 2 ? { min: 3, capacity: 8 } : { min: 1, capacity: 1 };
      const start = new Date(startAt);
      const end = plusMinutes(start, 45);
      const formationCheck = plusMinutes(start, -60);
      const cancelLock = plusMinutes(start, -50);
      const formationDecidedAt = formation === 'formed' ? mysqlDate(formationCheck) : (formation === 'failed' ? mysqlDate(cancelledAt || formationCheck) : null);
      await pool.execute(
        `INSERT INTO class_sessions (
           id, session_date, time_slot_id, start_at, end_at, course_id, class_type_id,
           teacher_id, classroom_id, min_students, capacity, booked_count,
           lifecycle_status, formation_status, formation_check_at, cancel_lock_at,
           booking_close_at, formation_decided_at, cancel_reason, cancelled_at, generation_key
         ) VALUES (?, ?, NULL, ?, ?, 9200, ?, 9200, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, mysqlDate(start).slice(0,10), mysqlDate(start), mysqlDate(end), classTypeId,
         type.min, type.capacity, bookedCount, lifecycle, formation,
         mysqlDate(formationCheck), mysqlDate(cancelLock), mysqlDate(start), formationDecidedAt,
         cancelReason, cancelledAt ? mysqlDate(cancelledAt) : null, `phase1d-smoke-${id}`]
      );
    }

    async function seedConfirmed(sessionId, ids) {
      const bookingIds = [];
      for (const userId of ids) {
        const [result] = await pool.execute(`INSERT INTO bookings (session_id, user_id, status, source) VALUES (?, ?, 'confirmed', 'student')`, [sessionId, userId]);
        bookingIds.push(result.insertId);
      }
      await pool.execute(`UPDATE class_sessions SET booked_count = ? WHERE id = ?`, [ids.length, sessionId]);
      return bookingIds;
    }

    async function seedSystemCancelled(sessionId, userId, at) {
      const [result] = await pool.execute(
        `INSERT INTO bookings (session_id, user_id, status, source, cancelled_at, cancel_reason)
         VALUES (?, ?, 'system_cancelled', 'student', ?, 'insufficient_students')`,
        [sessionId, userId, mysqlDate(at)]
      );
      return result.insertId;
    }

    function makeStack(nowValue) {
      const repository = new CancellationRepository({ pool });
      const formationService = new FormationService({ repository });
      const bookingService = new BookingService({ repository, formationService, now: () => new Date(nowValue) });
      const cancellationService = new CancellationService({ repository, formationService, now: () => new Date(nowValue) });
      return { repository, formationService, bookingService, cancellationService };
    }

    // A. T-60 before ordinary cancellation: 5 -> 4, open+pending remains.
    await createSession({ id: 6101 });
    const aBookings = await seedConfirmed(6101, [2001,2002,2003,2004,2005]);
    const a = await makeStack('2026-09-10T09:30:00.000Z').cancellationService.cancelBooking({ authContext: auth(2001), bookingId: aBookings[0] });
    const aSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=6101`);
    assertCheck(a.booking === undefined && a.payload.booking.status === 'cancelled', 'A pre-T60 learner booking becomes cancelled');
    assertCheck(aSession.lifecycle_status === 'open' && aSession.formation_status === 'pending', 'A pre-T60 session remains open+pending');
    assertCheck(aSession.booked_count === 4 && await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=6101 AND status='confirmed'`) === 4, 'A booked_count is authoritative 4 after 5->4');

    // B. Exact T-60 pending with only 2: formation happens first and system-cancels both.
    await createSession({ id: 6201 });
    const bBookings = await seedConfirmed(6201, [2006,2007]);
    const b = await makeStack('2026-09-10T10:00:00.000Z').cancellationService.cancelBooking({ authContext: auth(2006), bookingId: bBookings[0] });
    const bSession = await row(pool, `SELECT lifecycle_status, formation_status, cancel_reason, booked_count FROM class_sessions WHERE id=6201`);
    assertCheck(b.payload.booking.status === 'system_cancelled', 'B exact T-60 request returns system_cancelled current booking, not learner-cancelled');
    assertCheck(bSession.lifecycle_status === 'cancelled' && bSession.formation_status === 'failed' && bSession.cancel_reason === 'insufficient_students', 'B formation authority persists cancelled+failed+insufficient');
    assertCheck(bSession.booked_count === 0 && await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=6201 AND status='system_cancelled'`) === 2, 'B both original bookings system-cancel and booked_count=0');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE action='booking_cancelled_by_student' AND entity_id=?`, [String(bBookings[0])]) === 0, 'B learner cancellation does not run before T-60 formation decision');

    // C. Formed 3, T-60..T-50, one cancels => current cancelled, remaining 2 system_cancelled, whole session fails.
    await createSession({ id: 6301, formation: 'formed' });
    const cBookings = await seedConfirmed(6301, [2008,2009,2010]);
    const c = await makeStack('2026-09-10T10:05:00.000Z').cancellationService.cancelBooking({ authContext: auth(2008), bookingId: cBookings[0] });
    const cSession = await row(pool, `SELECT lifecycle_status, formation_status, cancel_reason, booked_count FROM class_sessions WHERE id=6301`);
    assertCheck(c.payload.booking.status === 'cancelled', 'C initiating learner remains cancelled');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=6301 AND status='system_cancelled'`) === 2, 'C remaining two learners are system_cancelled');
    assertCheck(cSession.lifecycle_status === 'cancelled' && cSession.formation_status === 'failed' && cSession.booked_count === 0, 'C formed 3->2 atomically cancels entire session');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=6301 AND type='insufficient_students_cancelled'`) === 6, 'C insufficient cancellation writes exactly remaining learners+teacher two-channel outbox');

    // D. Formed 5 -> 4 remains formed/open.
    await createSession({ id: 6401, formation: 'formed' });
    const dBookings = await seedConfirmed(6401, [2011,2012,2013,2014,2015]);
    await makeStack('2026-09-10T10:05:00.000Z').cancellationService.cancelBooking({ authContext: auth(2011), bookingId: dBookings[0] });
    const dSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=6401`);
    assertCheck(dSession.lifecycle_status === 'open' && dSession.formation_status === 'formed' && dSession.booked_count === 4, 'D formed 5->4 remains open+formed with authoritative count 4');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=6401 AND status='system_cancelled'`) === 0, 'D no whole-session system cancellation occurs at 4 learners');

    // E. Exact T-50 rejects and leaves state unchanged.
    await createSession({ id: 6501, formation: 'formed' });
    const eBookings = await seedConfirmed(6501, [2016,2017,2018,2019,2020]);
    const eResult = await Promise.allSettled([makeStack('2026-09-10T10:10:00.000Z').cancellationService.cancelBooking({ authContext: auth(2016), bookingId: eBookings[0] })]);
    assertCheck(resultCode(eResult[0]) === 'CANCEL_WINDOW_CLOSED', 'E exact T-50 is rejected as CANCEL_WINDOW_CLOSED');
    assertCheck((await row(pool, `SELECT status FROM bookings WHERE id=?`, [eBookings[0]])).status === 'confirmed' && (await row(pool, `SELECT booked_count FROM class_sessions WHERE id=6501`)).booked_count === 5, 'E exact T-50 rejection changes neither booking nor booked_count');

    // F. After T-50 rejects.
    await createSession({ id: 6601, formation: 'formed' });
    const fBookings = await seedConfirmed(6601, [2021,2022,2023,2024]);
    const fResult = await Promise.allSettled([makeStack('2026-09-10T10:30:00.000Z').cancellationService.cancelBooking({ authContext: auth(2021), bookingId: fBookings[0] })]);
    assertCheck(resultCode(fResult[0]) === 'CANCEL_WINDOW_CLOSED', 'F after T-50 is rejected as CANCEL_WINDOW_CLOSED');

    // G. Same booking two concurrent cancellations without key: only one actual mutation/log.
    await createSession({ id: 6701 });
    const gBookings = await seedConfirmed(6701, [2025,2026,2027,2028,2029]);
    const gService = makeStack('2026-09-10T09:30:00.000Z').cancellationService;
    const gRace = await Promise.allSettled([
      gService.cancelBooking({ authContext: auth(2025), bookingId: gBookings[0] }),
      gService.cancelBooking({ authContext: auth(2025), bookingId: gBookings[0] })
    ]);
    assertCheck(gRace.every(x => x.status === 'fulfilled'), 'G same booking concurrent cancellation requests both resolve safely');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM bookings WHERE id=? AND status='cancelled'`, [gBookings[0]]) === 1, 'G target booking has one final cancelled row');
    assertCheck((await row(pool, `SELECT booked_count FROM class_sessions WHERE id=6701`)).booked_count === 4, 'G booked_count decreases exactly once');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE action='booking_cancelled_by_student' AND entity_id=?`, [String(gBookings[0])]) === 1, 'G user cancellation operation log is written exactly once');

    // H. Same Idempotency-Key concurrently on formed 3->2: replay same result and no duplicate whole-cancel side effects.
    await createSession({ id: 6801, formation: 'formed' });
    const hBookings = await seedConfirmed(6801, [2030,2031,2032]);
    const hService = makeStack('2026-09-10T10:05:00.000Z').cancellationService;
    const hRace = await Promise.allSettled([
      hService.cancelBooking({ authContext: auth(2030), bookingId: hBookings[0], idempotencyKey: 'phase1d-cancel-6801' }),
      hService.cancelBooking({ authContext: auth(2030), bookingId: hBookings[0], idempotencyKey: 'phase1d-cancel-6801' })
    ]);
    assertCheck(hRace.every(x => x.status === 'fulfilled'), 'H same cancellation Idempotency-Key concurrent requests both return success');
    assertCheck(new Set(hRace.map(x => JSON.stringify(x.value.payload))).size === 1, 'H idempotent cancellation returns the same business payload');
    assertCheck(hRace.filter(x => x.value.idempotentReplay === true).length === 1, 'H one cancellation request is an idempotent replay');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM idempotency_keys WHERE user_id=2030 AND scope='POST /bookings/:id/cancel' AND idempotency_key='phase1d-cancel-6801' AND state='completed'`) === 1, 'H isolated cancellation idempotency row completes exactly once');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='6801' AND action='session_cancelled_insufficient_students'`) === 1, 'H whole-session insufficient operation log is not duplicated');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=6801 AND type='insufficient_students_cancelled'`) === 6, 'H insufficient cancellation outbox is not duplicated by replay');

    // I. Cancellation races T-60 formation task. Session lock serializes to one consistent result.
    await createSession({ id: 6901 });
    const iBookings = await seedConfirmed(6901, [2033,2034,2035]);
    const iStack = makeStack('2026-09-10T10:00:00.000Z');
    const iFormationTask = withTransaction(pool, async connection => {
      const locked = await iStack.repository.lockSession(6901, connection);
      return iStack.formationService.ensureFormationDecision({ connection, session: locked, now: new Date('2026-09-10T10:00:00.000Z') });
    });
    const iCancel = iStack.cancellationService.cancelBooking({ authContext: auth(2033), bookingId: iBookings[0] });
    const iRace = await Promise.allSettled([iFormationTask, iCancel]);
    assertCheck(iRace.every(x => x.status === 'fulfilled'), 'I cancellation and T-60 formation task both complete under session-first serialization');
    const iSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=6901`);
    assertCheck(iSession.lifecycle_status === 'cancelled' && iSession.formation_status === 'failed' && iSession.booked_count === 0, 'I race converges to cancelled+failed with zero booked_count');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=6901 AND status='cancelled'`) === 1 && await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=6901 AND status='system_cancelled'`) === 2, 'I race preserves initiating cancellation and system-cancels remaining two');

    // J. Cancellation races a new booking on same session; session lock prevents count drift/oversell.
    await createSession({ id: 7001, formation: 'formed' });
    const jUsers = [];
    for (let id = 2036; id <= 2052; id += 1) jUsers.push(id); // 17 existing
    const jBookings = await seedConfirmed(7001, jUsers);
    const jStack = makeStack('2026-09-10T10:05:00.000Z');
    const jRace = await Promise.allSettled([
      jStack.cancellationService.cancelBooking({ authContext: auth(2036), bookingId: jBookings[0] }),
      jStack.bookingService.createBooking({ authContext: auth(2053), sessionId: 7001 })
    ]);
    assertCheck(jRace.every(x => x.status === 'fulfilled'), 'J cancellation and new booking on same session both complete without deadlock');
    const jConfirmed = await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=7001 AND status='confirmed'`);
    const jSession = await row(pool, `SELECT booked_count, capacity FROM class_sessions WHERE id=7001`);
    assertCheck(jConfirmed === 17 && jSession.booked_count === 17, 'J booked_count equals authoritative confirmed count after cancel/book race');
    assertCheck(jSession.booked_count <= jSession.capacity, 'J cancel/book race never oversells capacity');

    // K. User cannot cancel another learner booking.
    await createSession({ id: 7101 });
    const kBookings = await seedConfirmed(7101, [2054,2055,2056]);
    const kResult = await Promise.allSettled([makeStack('2026-09-10T09:30:00.000Z').cancellationService.cancelBooking({ authContext: auth(2055), bookingId: kBookings[0] })]);
    assertCheck(resultCode(kResult[0]) === 'FORBIDDEN', 'K foreign learner cancellation is rejected as FORBIDDEN');
    assertCheck((await row(pool, `SELECT status FROM bookings WHERE id=?`, [kBookings[0]])).status === 'confirmed' && (await row(pool, `SELECT booked_count FROM class_sessions WHERE id=7101`)).booked_count === 3, 'K foreign cancellation leaves target booking and booked_count unchanged');

    // L. Already system_cancelled booking receives stale cancellation request: return latest, no repeat effects.
    await createSession({ id: 7201, lifecycle: 'cancelled', formation: 'failed', bookedCount: 0, cancelReason: 'insufficient_students', cancelledAt: '2026-09-10T10:00:00.000Z' });
    const lBooking = await seedSystemCancelled(7201, 2057, '2026-09-10T10:00:00.000Z');
    const beforeLNotifications = await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=7201`);
    const beforeLLogs = await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id IN (?,?)`, [String(lBooking), '7201']);
    const l = await makeStack('2026-09-10T10:06:00.000Z').cancellationService.cancelBooking({ authContext: auth(2057), bookingId: lBooking });
    assertCheck(l.payload.booking.status === 'system_cancelled' && l.payload.session.lifecycle_status === 'cancelled', 'L stale cancellation returns latest system-cancelled/session-cancelled state');
    assertCheck((await row(pool, `SELECT booked_count FROM class_sessions WHERE id=7201`)).booked_count === 0, 'L stale cancellation does not decrement booked_count below zero');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=7201`) === beforeLNotifications, 'L stale cancellation writes no duplicate notifications');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id IN (?,?)`, [String(lBooking), '7201']) === beforeLLogs, 'L stale cancellation writes no duplicate operation logs');

    console.log(`SUMMARY | pass=${passCount} fail=${failCount}`);
    if (failCount > 0) process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main().catch(error => {
  console.error('FATAL | phase1d cancellation mysql smoke crashed');
  console.error(error && error.stack ? error.stack : error);
  process.exitCode = 1;
});
