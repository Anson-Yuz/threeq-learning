'use strict';

const { ERROR_CODE } = require('../domain/constants');
const { AppError } = require('../auth/errors');

const STATUS_BY_CODE = Object.freeze({
  [ERROR_CODE.SESSION_NOT_FOUND]: 404,
  [ERROR_CODE.SESSION_CANCELLED]: 409,
  [ERROR_CODE.SESSION_STARTED]: 409,
  [ERROR_CODE.BOOKING_CLOSED]: 409,
  [ERROR_CODE.SESSION_FULL]: 409,
  [ERROR_CODE.FORMATION_FAILED]: 409,
  [ERROR_CODE.ALREADY_BOOKED]: 409,
  [ERROR_CODE.STUDENT_TIME_CONFLICT]: 409,
  [ERROR_CODE.CANCEL_WINDOW_CLOSED]: 409,
  [ERROR_CODE.IDEMPOTENCY_CONFLICT]: 409
});

function bookingError(code, message = code, details = null) {
  return new AppError({ code, message, status: STATUS_BY_CODE[code] || 409, details });
}

module.exports = Object.freeze({ bookingError });
