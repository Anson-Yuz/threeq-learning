'use strict';

const { withTransaction } = require('../db/pool');
const { LIFECYCLE_STATUS, FORMATION_STATUS } = require('../domain/constants');
const { reconcileLifecycleStatus } = require('../domain/sessionRules');

const DEFAULT_BATCH_SIZE = 100;
const MAX_BATCH_SIZE = 1000;

function toDate(value, fieldName = 'now') {
  const date = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(date.getTime())) throw new TypeError(`${fieldName} must be a valid instant`);
  return date;
}

function normalizeBatchSize(value) {
  const batchSize = value === undefined || value === null ? DEFAULT_BATCH_SIZE : Number(value);
  if (!Number.isInteger(batchSize) || batchSize < 1 || batchSize > MAX_BATCH_SIZE) {
    throw new RangeError(`batchSize must be an integer between 1 and ${MAX_BATCH_SIZE}`);
  }
  return batchSize;
}

function sessionSnapshot(session) {
  if (!session) return null;
  return Object.freeze({
    id: String(session.id),
    lifecycle_status: session.lifecycle_status,
    formation_status: session.formation_status,
    booked_count: Number(session.booked_count),
    formation_decided_at: session.formation_decided_at || null,
    cancel_reason: session.cancel_reason === undefined ? null : session.cancel_reason,
    cancelled_at: session.cancelled_at || null
  });
}

class FormationWorker {
  constructor({
    repository,
    formationService,
    now = () => new Date(),
    transactionRunner = withTransaction,
    batchSize = DEFAULT_BATCH_SIZE
  }) {
    if (!repository || !repository.pool) throw new TypeError('repository.pool is required');
    if (!formationService || typeof formationService.ensureFormationDecision !== 'function') {
      throw new TypeError('formationService.ensureFormationDecision is required');
    }
    if (typeof now !== 'function') throw new TypeError('now must be a function');
    if (typeof transactionRunner !== 'function') throw new TypeError('transactionRunner must be a function');

    this.repository = repository;
    this.formationService = formationService;
    this.now = now;
    this.transactionRunner = transactionRunner;
    this.batchSize = normalizeBatchSize(batchSize);
  }

  async processSession(sessionId, { now = null } = {}) {
    const decisionNow = toDate(now === null ? this.now() : now);

    return this.transactionRunner(this.repository.pool, async (connection) => {
      let session = await this.repository.lockSession(sessionId, connection);
      if (!session) {
        return Object.freeze({
          sessionId: String(sessionId),
          outcome: 'missing',
          decision: null,
          session: null
        });
      }

      // A stale/retry input must never re-decide an already authoritative state.
      if (session.formation_status !== FORMATION_STATUS.PENDING) {
        return Object.freeze({
          sessionId: String(session.id),
          outcome: 'noop',
          decision: session.formation_status,
          session: sessionSnapshot(session)
        });
      }

      // Cancelled/draft are authoritative no-op states. Do not perform lifecycle
      // reconciliation or Formation side effects for them.
      if (
        session.lifecycle_status === LIFECYCLE_STATUS.CANCELLED ||
        session.lifecycle_status === LIFECYCLE_STATUS.DRAFT
      ) {
        return Object.freeze({
          sessionId: String(session.id),
          outcome: 'noop',
          decision: session.formation_status,
          session: sessionSnapshot(session)
        });
      }

      // This is not a general lifecycle scheduler. Reconciliation is performed only
      // because a pending Formation decision is being evaluated and delayed execution
      // may have crossed start_at/end_at.
      const reconciled = reconcileLifecycleStatus({
        lifecycleStatus: session.lifecycle_status,
        now: decisionNow,
        startAt: session.start_at,
        endAt: session.end_at
      });
      if (reconciled !== session.lifecycle_status) {
        const updated = await this.repository.updateLifecycleStatus(session.id, reconciled, connection);
        if (!updated) {
          const authoritative = await this.repository.lockSession(session.id, connection);
          return Object.freeze({
            sessionId: String(session.id),
            outcome: 'noop',
            decision: authoritative ? authoritative.formation_status : null,
            session: sessionSnapshot(authoritative || session)
          });
        }
        session.lifecycle_status = reconciled;
      }

      if (decisionNow.getTime() < toDate(session.formation_check_at, 'formation_check_at').getTime()) {
        return Object.freeze({
          sessionId: String(session.id),
          outcome: 'noop',
          decision: FORMATION_STATUS.PENDING,
          session: sessionSnapshot(session)
        });
      }

      const result = await this.formationService.ensureFormationDecision({
        connection,
        session,
        now: decisionNow
      });
      session = result.session;

      let outcome = 'noop';
      if (result.decision === FORMATION_STATUS.FORMED) outcome = 'formed';
      else if (result.decision === FORMATION_STATUS.FAILED) outcome = 'cancelled';
      else if (result.decision === FORMATION_STATUS.NOT_REQUIRED) outcome = 'not_required';

      return Object.freeze({
        sessionId: String(session.id),
        outcome,
        decision: result.decision,
        confirmedCount: result.confirmedCount === undefined ? null : Number(result.confirmedCount),
        session: sessionSnapshot(session)
      });
    });
  }

  async runOnce({ batchSize = this.batchSize } = {}) {
    const normalizedBatchSize = normalizeBatchSize(batchSize);
    const scanNow = toDate(this.now());
    const candidateIds = await this.repository.findDueOpenPendingSessionIds({
      now: scanNow,
      batchSize: normalizedBatchSize
    });

    const results = [];
    for (const sessionId of candidateIds) {
      try {
        // Each candidate gets its own transaction. Failure isolation is deliberate.
        results.push(await this.processSession(sessionId));
      } catch (error) {
        results.push(Object.freeze({
          sessionId: String(sessionId),
          outcome: 'error',
          error: Object.freeze({
            code: error && error.code ? String(error.code) : 'FORMATION_WORKER_ERROR',
            message: error && error.message ? String(error.message) : 'Unknown formation worker error'
          })
        }));
      }
    }

    const summary = results.reduce((acc, item) => {
      acc[item.outcome] = (acc[item.outcome] || 0) + 1;
      return acc;
    }, {});

    return Object.freeze({
      scannedAt: scanNow.toISOString(),
      batchSize: normalizedBatchSize,
      candidateCount: candidateIds.length,
      formedCount: summary.formed || 0,
      cancelledCount: summary.cancelled || 0,
      notRequiredCount: summary.not_required || 0,
      noopCount: summary.noop || 0,
      missingCount: summary.missing || 0,
      errorCount: summary.error || 0,
      results: Object.freeze(results)
    });
  }
}

module.exports = Object.freeze({
  DEFAULT_BATCH_SIZE,
  MAX_BATCH_SIZE,
  FormationWorker,
  normalizeBatchSize
});
