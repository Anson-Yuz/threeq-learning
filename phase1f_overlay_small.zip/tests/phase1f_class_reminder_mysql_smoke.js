'use strict';

const mysql = require('mysql2/promise');
const { ClassReminderRepository } = require('../backend/booking/classReminderRepository');
const { FormationWorkerRepository } = require('../backend/booking/formationWorkerRepository');
const { CancellationRepository } = require('../backend/booking/cancellationRepository');
const { FormationService } = require('../backend/booking/formationService');
const { BookingService } = require('../backend/booking/bookingService');
const { FormationWorker } = require('../backend/jobs/formationWorker');
const { ClassReminderWorker } = require('../backend/jobs/classReminderWorker');

const DB = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'root',
  database: process.env.DB_NAME || 'hubeier_phase1f_smoke',
  timezone: 'Z',
  dateStrings: false,
  waitForConnections: true,
  connectionLimit: 20
};

let pass = 0;
let fail = 0;
function ok(condition, label) {
  if (condition) { pass += 1; console.log(`PASS | ${label}`); }
  else { fail += 1; console.log(`FAIL | ${label}`); }
}
function eq(actual, expected, label) { ok(actual === expected, `${label} | expected=${expected} actual=${actual}`); }
function plusMinutes(date, minutes) { return new Date(date.getTime() + minutes * 60000); }
function iso(d) { return new Date(d).toISOString(); }

async function scalar(pool, sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  const row = rows[0] || {};
  return Number(Object.values(row)[0] || 0);
}
async function row(pool, sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows[0] || null;
}

async function clearData(pool) {
  await pool.execute('SET FOREIGN_KEY_CHECKS=0');
  for (const table of ['idempotency_keys','operation_logs','notifications','subscription_consents','bookings','class_sessions','weekly_templates','teachers','user_roles','users','courses']) {
    await pool.execute(`DELETE FROM ${table}`);
  }
  await pool.execute('SET FOREIGN_KEY_CHECKS=1');
}

async function seedPeople(pool) {
  const ids = [];
  for (let i = 1; i <= 20; i += 1) {
    const openid = `phase1f_openid_${i}`;
    const [r] = await pool.execute('INSERT INTO users (openid, nickname, status) VALUES (?, ?, \'active\')', [openid, `U${i}`]);
    ids.push(r.insertId);
    await pool.execute("INSERT INTO user_roles (user_id, role_code) VALUES (?, 'student')", [r.insertId]);
  }
  const teacherUserId = ids[19];
  await pool.execute("INSERT IGNORE INTO user_roles (user_id, role_code) VALUES (?, 'teacher')", [teacherUserId]);
  const [teacher] = await pool.execute("INSERT INTO teachers (user_id, name, status) VALUES (?, '贝儿老师', 'active')", [teacherUserId]);
  const [course] = await pool.execute("INSERT INTO courses (name, enabled) VALUES ('综合形体', 1)");
  return { students: ids.slice(0, 19), teacherUserId, teacherId: teacher.insertId, courseId: course.insertId };
}

async function createSession(pool, ctx, {
  classTypeId = 1,
  lifecycle = 'open',
  formation = 'pending',
  startAt,
  bookedCount = 0,
  cancelReason = null,
  cancelledAt = null,
  formationDecidedAt = null
}) {
  const min = classTypeId === 3 ? 1 : 3;
  const cap = classTypeId === 1 ? 18 : classTypeId === 2 ? 8 : 1;
  const formationCheckAt = plusMinutes(startAt, -60);
  const cancelLockAt = plusMinutes(startAt, -50);
  const [r] = await pool.execute(
    `INSERT INTO class_sessions
      (session_date, start_at, end_at, course_id, class_type_id, teacher_id, classroom_id,
       min_students, capacity, booked_count, lifecycle_status, formation_status,
       formation_check_at, cancel_lock_at, booking_close_at, formation_decided_at,
       cancel_reason, cancelled_at)
     VALUES ('2026-09-10', ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [startAt, plusMinutes(startAt, 45), ctx.courseId, classTypeId, ctx.teacherId,
      min, cap, bookedCount, lifecycle, formation, formationCheckAt, cancelLockAt,
      startAt, formationDecidedAt, cancelReason, cancelledAt]
  );
  return { id: r.insertId, startAt, formationCheckAt, cancelLockAt };
}

async function addBooking(pool, sessionId, userId, createdAt, status = 'confirmed') {
  const cancelledAt = status === 'confirmed' ? null : createdAt;
  const [r] = await pool.execute(
    `INSERT INTO bookings (session_id, user_id, status, source, created_at, cancelled_at)
     VALUES (?, ?, ?, 'student', ?, ?)`,
    [sessionId, userId, status, createdAt, cancelledAt]
  );
  return r.insertId;
}

async function setBookedCountFromDb(pool, sessionId) {
  const n = await scalar(pool, "SELECT COUNT(*) AS n FROM bookings WHERE session_id=? AND status='confirmed'", [sessionId]);
  await pool.execute('UPDATE class_sessions SET booked_count=? WHERE id=?', [n, sessionId]);
  return n;
}

function makeReminder(pool, now) {
  const repo = new ClassReminderRepository({ pool });
  const formationService = new FormationService({ repository: repo });
  const worker = new ClassReminderWorker({ repository: repo, formationService, now: () => new Date(now) });
  return { repo, formationService, worker };
}
function makeFormation(pool, now) {
  const repo = new FormationWorkerRepository({ pool });
  const formationService = new FormationService({ repository: repo });
  const worker = new FormationWorker({ repository: repo, formationService, now: () => new Date(now) });
  return { repo, formationService, worker };
}
function makeBooking(pool, now) {
  const repo = new ClassReminderRepository({ pool });
  const formationService = new FormationService({ repository: repo });
  return new BookingService({ repository: repo, formationService, now: () => new Date(now) });
}

async function reminderCount(pool, sessionId, userId = null) {
  return scalar(pool,
    `SELECT COUNT(*) AS n FROM notifications WHERE session_id=? AND type='class_reminder'${userId === null ? '' : ' AND user_id=?'}`,
    userId === null ? [sessionId] : [sessionId, userId]);
}
async function typeCount(pool, sessionId, type) {
  return scalar(pool, 'SELECT COUNT(*) AS n FROM notifications WHERE session_id=? AND type=?', [sessionId, type]);
}
async function logCount(pool, sessionId, action) {
  return scalar(pool, "SELECT COUNT(*) AS n FROM operation_logs WHERE entity_type='class_session' AND entity_id=? AND action=?", [String(sessionId), action]);
}

async function main() {
  const pool = mysql.createPool(DB);
  try {
    const version = await row(pool, 'SELECT VERSION() AS version, @@transaction_isolation AS isolation');
    console.log(`MYSQL_VERSION=${version.version}`);
    console.log(`TRANSACTION_ISOLATION=${version.isolation}`);
    ok(String(version.version).startsWith('8.'), 'real MySQL 8.x instance is running');
    eq(String(version.isolation).toUpperCase(), 'REPEATABLE-READ', 'reminder concurrency smoke uses REPEATABLE READ');

    await clearData(pool);
    const ctx = await seedPeople(pool);
    const START = new Date('2026-09-10T11:00:00.000Z');
    const T60 = plusMinutes(START, -60);
    const T60_MINUS = new Date(T60.getTime() - 1);
    const T60_PLUS10 = plusMinutes(T60, 10);
    const EARLY = plusMinutes(T60, -10);
    const LATE = plusMinutes(T60, 1);

    // A. Before T-60: zero reminder.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'pending' });
      for (let i=0;i<3;i++) await addBooking(pool, s.id, ctx.students[i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const { worker } = makeReminder(pool, T60_MINUS);
      const result = await worker.runOnce();
      eq(result.candidateCount, 0, 'A before T-60 candidate scan finds nothing');
      eq(await reminderCount(pool, s.id), 0, 'A before T-60 creates zero reminder');
    }

    // B. Group exact T-60, 3 -> formed + 8 reminder deliveries.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'pending' });
      for (let i=0;i<3;i++) await addBooking(pool, s.id, ctx.students[i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const { worker } = makeReminder(pool, T60);
      await worker.processSession(s.id, { now: T60 });
      const ss = await row(pool, 'SELECT lifecycle_status, formation_status, formation_decided_at FROM class_sessions WHERE id=?', [s.id]);
      eq(ss.lifecycle_status, 'open', 'B 3-person group remains open');
      eq(ss.formation_status, 'formed', 'B 3-person group forms before reminder');
      ok(ss.formation_decided_at !== null, 'B formation_decided_at is set');
      eq(await reminderCount(pool, s.id), 8, 'B 3 learners + teacher x 2 channels = 8 reminders');
      eq(await logCount(pool, s.id, 'formation_formed'), 1, 'B formation log is once');
      eq(await logCount(pool, s.id, 'class_reminder_generated'), 1, 'B reminder audit is once');
    }

    // C. Group exact T-60, 2 -> cancellation chain only, no class_reminder.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'pending' });
      for (let i=0;i<2;i++) await addBooking(pool, s.id, ctx.students[3+i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const { worker } = makeReminder(pool, T60);
      await worker.processSession(s.id, { now: T60 });
      const ss = await row(pool, 'SELECT lifecycle_status, formation_status, booked_count, cancel_reason FROM class_sessions WHERE id=?', [s.id]);
      eq(`${ss.lifecycle_status}:${ss.formation_status}:${ss.cancel_reason}`, 'cancelled:failed:insufficient_students', 'C 2-person group auto-cancels');
      eq(Number(ss.booked_count), 0, 'C cancellation zeroes booked_count');
      eq(await reminderCount(pool, s.id), 0, 'C failed group creates no class_reminder');
      eq(await typeCount(pool, s.id, 'insufficient_students_cancelled'), 6, 'C only insufficient cancellation student+teacher two-channel chain exists');
    }

    // D. Already formed group -> reminders once.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'formed', formationDecidedAt: T60 });
      for (let i=0;i<3;i++) await addBooking(pool, s.id, ctx.students[5+i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const { worker } = makeReminder(pool, T60);
      await worker.processSession(s.id, { now: T60 });
      eq(await reminderCount(pool, s.id), 8, 'D already formed group generates reminders once');
      eq(await logCount(pool, s.id, 'class_reminder_generated'), 1, 'D reminder audit once');
    }

    // E/F. Private with pre-T60 booking / no booking.
    {
      const s = await createSession(pool, ctx, { startAt: START, classTypeId: 3, formation: 'not_required' });
      await addBooking(pool, s.id, ctx.students[8], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const { worker } = makeReminder(pool, T60);
      await worker.processSession(s.id, { now: T60 });
      eq(await reminderCount(pool, s.id), 4, 'E private learner + teacher x 2 channels = 4 reminders');

      const empty = await createSession(pool, ctx, { startAt: START, classTypeId: 3, formation: 'not_required' });
      await worker.processSession(empty.id, { now: T60 });
      eq(await reminderCount(pool, empty.id), 0, 'F private with no booking has zero reminder');
    }

    // G. Post-T60 group booking keeps booking_success but never receives retroactive reminder.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'formed', formationDecidedAt: T60 });
      for (let i=0;i<3;i++) await addBooking(pool, s.id, ctx.students[9+i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const lateUser = ctx.students[12];
      const booking = makeBooking(pool, T60_PLUS10);
      const response = await booking.createBooking({ authContext: { user: { id: lateUser } }, sessionId: s.id, idempotencyKey: 'phase1f-g-late' });
      const bookingId = Number(response.payload.booking.id);
      await pool.execute('UPDATE bookings SET created_at=? WHERE id=?', [LATE, bookingId]);
      const { worker } = makeReminder(pool, T60_PLUS10);
      await worker.processSession(s.id, { now: T60_PLUS10 });
      eq(await reminderCount(pool, s.id, lateUser), 0, 'G post-T60 group learner gets no retroactive class_reminder');
      eq(await scalar(pool, "SELECT COUNT(*) AS n FROM notifications WHERE session_id=? AND user_id=? AND type='booking_success'", [s.id, lateUser]), 2, 'G post-T60 group learner retains two-channel booking_success');
    }

    // H. Post-T60 private booking is also excluded from reminder.
    {
      const s = await createSession(pool, ctx, { startAt: START, classTypeId: 3, formation: 'not_required' });
      const lateUser = ctx.students[13];
      const booking = makeBooking(pool, T60_PLUS10);
      const response = await booking.createBooking({ authContext: { user: { id: lateUser } }, sessionId: s.id, idempotencyKey: 'phase1f-h-private' });
      const bookingId = Number(response.payload.booking.id);
      await pool.execute('UPDATE bookings SET created_at=? WHERE id=?', [LATE, bookingId]);
      const { worker } = makeReminder(pool, T60_PLUS10);
      await worker.processSession(s.id, { now: T60_PLUS10 });
      eq(await reminderCount(pool, s.id), 0, 'H post-T60 private booking gets no retroactive reminder for learner or teacher');
      eq(await scalar(pool, "SELECT COUNT(*) AS n FROM notifications WHERE session_id=? AND user_id=? AND type='booking_success'", [s.id, lateUser]), 2, 'H private late booking keeps booking_success');
    }

    // I/J. Two reminder workers and retry dedupe.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'formed', formationDecidedAt: T60 });
      for (let i=0;i<3;i++) await addBooking(pool, s.id, ctx.students[i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const w1 = makeReminder(pool, T60).worker;
      const w2 = makeReminder(pool, T60).worker;
      await Promise.all([w1.processSession(s.id, { now: T60 }), w2.processSession(s.id, { now: T60 })]);
      eq(await reminderCount(pool, s.id), 8, 'I concurrent reminder workers dedupe to 8 deliveries');
      eq(await logCount(pool, s.id, 'class_reminder_generated'), 1, 'I concurrent reminder workers write one audit');
      await w1.processSession(s.id, { now: T60_PLUS10 });
      eq(await reminderCount(pool, s.id), 8, 'J retry creates no duplicate reminder');
      eq(await logCount(pool, s.id, 'class_reminder_generated'), 1, 'J retry creates no duplicate audit');
    }

    // K1. Reminder worker vs FormationWorker, 3 -> formed + reminder once.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'pending' });
      for (let i=0;i<3;i++) await addBooking(pool, s.id, ctx.students[3+i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const reminder = makeReminder(pool, T60).worker;
      const formation = makeFormation(pool, T60).worker;
      await Promise.all([reminder.processSession(s.id, { now: T60 }), formation.processSession(s.id, { now: T60 })]);
      const ss = await row(pool, 'SELECT lifecycle_status, formation_status FROM class_sessions WHERE id=?', [s.id]);
      eq(`${ss.lifecycle_status}:${ss.formation_status}`, 'open:formed', 'K1 reminder vs FormationWorker converges to open+formed');
      eq(await reminderCount(pool, s.id), 8, 'K1 reminder vs FormationWorker produces reminder once');
      eq(await logCount(pool, s.id, 'formation_formed'), 1, 'K1 formation log once');
    }

    // K2. Reminder worker vs FormationWorker, 2 -> cancelled and reminder zero.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'pending' });
      for (let i=0;i<2;i++) await addBooking(pool, s.id, ctx.students[6+i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const reminder = makeReminder(pool, T60).worker;
      const formation = makeFormation(pool, T60).worker;
      await Promise.all([reminder.processSession(s.id, { now: T60 }), formation.processSession(s.id, { now: T60 })]);
      const ss = await row(pool, 'SELECT lifecycle_status, formation_status FROM class_sessions WHERE id=?', [s.id]);
      eq(`${ss.lifecycle_status}:${ss.formation_status}`, 'cancelled:failed', 'K2 reminder vs FormationWorker converges to cancelled+failed');
      eq(await reminderCount(pool, s.id), 0, 'K2 failed course has zero reminder');
      eq(await logCount(pool, s.id, 'session_cancelled_insufficient_students'), 1, 'K2 cancellation log once');
    }

    // L. Reminder worker vs third booking when T-60 authoritative count is 2.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'pending' });
      for (let i=0;i<2;i++) await addBooking(pool, s.id, ctx.students[8+i], EARLY);
      await setBookedCountFromDb(pool, s.id);
      const reminder = makeReminder(pool, T60).worker;
      const booking = makeBooking(pool, T60);
      const third = ctx.students[10];
      const settled = await Promise.allSettled([
        reminder.processSession(s.id, { now: T60 }),
        booking.createBooking({ authContext: { user: { id: third } }, sessionId: s.id, idempotencyKey: 'phase1f-l-third' })
      ]);
      const bookingResult = settled[1];
      ok(bookingResult.status === 'rejected' && bookingResult.reason && bookingResult.reason.code === 'SESSION_CANCELLED', 'L third booking cannot rescue T-60 two-person course');
      eq(await reminderCount(pool, s.id), 0, 'L reminder remains zero on failed course');
      eq(await scalar(pool, 'SELECT COUNT(*) AS n FROM bookings WHERE session_id=? AND user_id=?', [s.id, third]), 0, 'L third learner booking row is never created');
    }

    // M. Cancelled / draft no-op.
    {
      const cancelled = await createSession(pool, ctx, { startAt: START, lifecycle: 'cancelled', formation: 'pending', cancelReason: 'admin_cancelled', cancelledAt: T60_MINUS });
      const draft = await createSession(pool, ctx, { startAt: START, lifecycle: 'draft', formation: 'pending' });
      const worker = makeReminder(pool, T60).worker;
      await worker.processSession(cancelled.id, { now: T60 });
      await worker.processSession(draft.id, { now: T60 });
      eq(await reminderCount(pool, cancelled.id), 0, 'M cancelled session no-op');
      eq(await reminderCount(pool, draft.id), 0, 'M draft session no-op');
      eq(await logCount(pool, cancelled.id, 'class_reminder_generated'), 0, 'M cancelled session creates no reminder audit');
    }

    // N/O. At start / in_progress / finished never backfill reminders.
    {
      const atStart = await createSession(pool, ctx, { startAt: START, formation: 'formed', formationDecidedAt: T60 });
      for (let i=0;i<3;i++) await addBooking(pool, atStart.id, ctx.students[i], EARLY);
      await setBookedCountFromDb(pool, atStart.id);
      const inProgress = await createSession(pool, ctx, { startAt: plusMinutes(START,-10), lifecycle: 'in_progress', formation: 'formed', formationDecidedAt: plusMinutes(START,-70) });
      const finished = await createSession(pool, ctx, { startAt: plusMinutes(START,-120), lifecycle: 'finished', formation: 'formed', formationDecidedAt: plusMinutes(START,-180) });
      const worker = makeReminder(pool, START).worker;
      await worker.processSession(atStart.id, { now: START });
      await worker.processSession(inProgress.id, { now: START });
      await worker.processSession(finished.id, { now: START });
      eq(await reminderCount(pool, atStart.id), 0, 'N exact start_at does not backfill reminder');
      eq(await reminderCount(pool, inProgress.id), 0, 'N in_progress does not backfill reminder');
      eq(await reminderCount(pool, finished.id), 0, 'O finished does not backfill reminder');
    }

    // P. Delayed but still pre-start: only early current confirmed bookings receive reminders.
    {
      const s = await createSession(pool, ctx, { startAt: START, formation: 'formed', formationDecidedAt: T60 });
      const earlyUsers = [ctx.students[3], ctx.students[4], ctx.students[5]];
      for (const u of earlyUsers) await addBooking(pool, s.id, u, EARLY);
      const lateUser = ctx.students[6];
      await addBooking(pool, s.id, lateUser, LATE);
      await setBookedCountFromDb(pool, s.id);
      const worker = makeReminder(pool, T60_PLUS10).worker;
      await worker.processSession(s.id, { now: T60_PLUS10 });
      for (const u of earlyUsers) eq(await reminderCount(pool, s.id, u), 2, `P early current confirmed user ${u} receives two-channel reminder`);
      eq(await reminderCount(pool, s.id, lateUser), 0, 'P T-60+ learner is excluded from delayed reminder');
      eq(await reminderCount(pool, s.id, ctx.teacherUserId), 2, 'P teacher still receives two-channel reminder');
      eq(await reminderCount(pool, s.id), 8, 'P delayed pre-start reminder totals early learners + teacher only');
    }

    console.log(`SUMMARY | pass=${pass} fail=${fail}`);
    if (fail > 0) process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error(error && error.stack ? error.stack : error);
  process.exitCode = 1;
});
