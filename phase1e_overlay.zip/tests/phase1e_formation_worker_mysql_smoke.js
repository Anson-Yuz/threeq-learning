'use strict';

const mysql = require('mysql2/promise');
const { FormationWorkerRepository } = require('../backend/booking/formationWorkerRepository');
const { CancellationRepository } = require('../backend/booking/cancellationRepository');
const { FormationService } = require('../backend/booking/formationService');
const { FormationWorker } = require('../backend/jobs/formationWorker');
const { BookingService } = require('../backend/booking/bookingService');
const { CancellationService } = require('../backend/booking/cancellationService');

let passCount = 0;
let failCount = 0;
function pass(label) { passCount += 1; console.log(`PASS | ${label}`); }
function fail(label, detail = '') { failCount += 1; console.error(`FAIL | ${label}${detail ? ` | ${detail}` : ''}`); }
function assertCheck(condition, label, detail = '') { if (condition) pass(label); else fail(label, detail); }

function mysqlDate(value) {
  const d = value instanceof Date ? value : new Date(value);
  return d.toISOString().slice(0, 23).replace('T', ' ');
}
function plusMinutes(value, minutes) { return new Date(new Date(value).getTime() + minutes * 60_000); }
function auth(userId) { return { user: { id: userId, status: 'active' }, roles: ['student'], teacher: null }; }
async function count(pool, sql, params = []) { const [rows] = await pool.execute(sql, params); return Number(Object.values(rows[0])[0]); }
async function row(pool, sql, params = []) { const [rows] = await pool.execute(sql, params); return rows[0] || null; }

async function main() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: process.env.DB_NAME || 'hubeier_phase1e_smoke',
    timezone: 'Z', charset: 'utf8mb4', waitForConnections: true, connectionLimit: 40, dateStrings: false
  });

  try {
    const [versionRows] = await pool.execute('SELECT VERSION() AS version, @@transaction_isolation AS isolation');
    console.log(`MYSQL_VERSION=${versionRows[0].version}`);
    console.log(`TRANSACTION_ISOLATION=${versionRows[0].isolation}`);
    assertCheck(/^8\./.test(versionRows[0].version), 'real MySQL 8.x instance is running');
    assertCheck(String(versionRows[0].isolation).toUpperCase().includes('REPEATABLE'), 'formation worker concurrency test runs under REPEATABLE READ');

    await pool.execute(`INSERT INTO users (id, openid, real_name, status) VALUES (9300, 'phase1e-teacher', 'Phase1E Teacher', 'active')`);
    await pool.execute(`INSERT INTO user_roles (user_id, role_code) VALUES (9300, 'teacher')`);
    await pool.execute(`INSERT INTO teachers (id, user_id, name, status) VALUES (9300, 9300, 'Phase1E Teacher', 'active')`);
    await pool.execute(`INSERT INTO courses (id, name, enabled) VALUES (9300, 'Phase1E Course', 1)`);
    for (let id = 3001; id <= 3090; id += 1) {
      await pool.execute(`INSERT INTO users (id, openid, real_name, status) VALUES (?, ?, ?, 'active')`, [id, `phase1e-student-${id}`, `Student ${id}`]);
      await pool.execute(`INSERT INTO user_roles (user_id, role_code) VALUES (?, 'student')`, [id]);
    }

    async function createSession({
      id,
      startAt = '2026-09-10T11:00:00.000Z',
      classTypeId = 1,
      lifecycle = 'open',
      formation = 'pending',
      bookedCount = 0,
      cancelReason = null,
      cancelledAt = null
    }) {
      const type = classTypeId === 1 ? { min: 3, capacity: 18 } : classTypeId === 2 ? { min: 3, capacity: 8 } : { min: 1, capacity: 1 };
      const start = new Date(startAt);
      const end = plusMinutes(start, 45);
      const formationCheck = plusMinutes(start, -60);
      const cancelLock = plusMinutes(start, -50);
      const formationDecidedAt = formation === 'formed'
        ? mysqlDate(formationCheck)
        : (formation === 'failed' ? mysqlDate(cancelledAt || formationCheck) : null);
      await pool.execute(
        `INSERT INTO class_sessions (
           id, session_date, time_slot_id, start_at, end_at, course_id, class_type_id,
           teacher_id, classroom_id, min_students, capacity, booked_count,
           lifecycle_status, formation_status, formation_check_at, cancel_lock_at,
           booking_close_at, formation_decided_at, cancel_reason, cancelled_at, generation_key
         ) VALUES (?, ?, NULL, ?, ?, 9300, ?, 9300, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, mysqlDate(start).slice(0,10), mysqlDate(start), mysqlDate(end), classTypeId,
         type.min, type.capacity, bookedCount, lifecycle, formation,
         mysqlDate(formationCheck), mysqlDate(cancelLock), mysqlDate(start), formationDecidedAt,
         cancelReason, cancelledAt ? mysqlDate(cancelledAt) : null, `phase1e-smoke-${id}`]
      );
    }

    async function seedConfirmed(sessionId, userIds) {
      const ids = [];
      for (const userId of userIds) {
        const [result] = await pool.execute(
          `INSERT INTO bookings (session_id, user_id, status, source) VALUES (?, ?, 'confirmed', 'student')`,
          [sessionId, userId]
        );
        ids.push(result.insertId);
      }
      await pool.execute(`UPDATE class_sessions SET booked_count = ? WHERE id = ?`, [userIds.length, sessionId]);
      return ids;
    }

    function makeWorker(nowValue) {
      const repository = new FormationWorkerRepository({ pool });
      const formationService = new FormationService({ repository });
      const worker = new FormationWorker({ repository, formationService, now: () => new Date(nowValue), batchSize: 100 });
      return { repository, formationService, worker };
    }

    function makeStudentStack(nowValue) {
      const repository = new CancellationRepository({ pool });
      const formationService = new FormationService({ repository });
      const bookingService = new BookingService({ repository, formationService, now: () => new Date(nowValue) });
      const cancellationService = new CancellationService({ repository, formationService, now: () => new Date(nowValue) });
      return { repository, formationService, bookingService, cancellationService };
    }

    // A. Before T-60, pending session is not discovered/processed.
    await createSession({ id: 7101, startAt: '2026-09-10T11:00:00.000Z' });
    await seedConfirmed(7101, [3001,3002]);
    const aResult = await makeWorker('2026-09-10T09:59:59.999Z').worker.runOnce();
    const aSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=7101`);
    assertCheck(aResult.candidateCount === 0, 'A before T-60 pending session is not scanned as due');
    assertCheck(aSession.lifecycle_status === 'open' && aSession.formation_status === 'pending' && aSession.booked_count === 2, 'A before T-60 state remains open+pending with count unchanged');
    // Test cleanup only: keep this future candidate out of subsequent runOnce scans.
    await pool.execute(`UPDATE class_sessions SET lifecycle_status='draft' WHERE id=7101`);

    // B. Exact T-60, 2 learners -> failed cancellation, system bookings, count 0, side effects once.
    await createSession({ id: 7201 });
    await seedConfirmed(7201, [3003,3004]);
    const bResult = await makeWorker('2026-09-10T10:00:00.000Z').worker.runOnce();
    const bSession = await row(pool, `SELECT lifecycle_status, formation_status, cancel_reason, booked_count FROM class_sessions WHERE id=7201`);
    assertCheck(bResult.cancelledCount === 1 && bSession.lifecycle_status === 'cancelled' && bSession.formation_status === 'failed' && bSession.cancel_reason === 'insufficient_students', 'B exact T-60 with 2 learners becomes cancelled+failed+insufficient');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=7201 AND status='system_cancelled'`) === 2 && bSession.booked_count === 0, 'B all confirmed bookings system-cancel and booked_count becomes zero');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=7201 AND type='insufficient_students_cancelled'`) === 6, 'B insufficient cancellation student+teacher two-channel outbox is written once');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_type='class_session' AND entity_id='7201' AND action='session_cancelled_insufficient_students'`) === 1, 'B insufficient cancellation system log is written once');

    // C. Exact T-60, 3 learners -> formed, lifecycle remains open, log once, no reminder side effect.
    await createSession({ id: 7301 });
    await seedConfirmed(7301, [3005,3006,3007]);
    const cResult = await makeWorker('2026-09-10T10:00:00.000Z').worker.runOnce();
    const cSession = await row(pool, `SELECT lifecycle_status, formation_status, formation_decided_at, booked_count FROM class_sessions WHERE id=7301`);
    assertCheck(cResult.formedCount === 1 && cSession.lifecycle_status === 'open' && cSession.formation_status === 'formed' && cSession.formation_decided_at !== null, 'C exact T-60 with 3 learners becomes formed while lifecycle stays open');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_type='class_session' AND entity_id='7301' AND action='formation_formed'`) === 1, 'C formation_formed system log is written once');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=7301`) === 0, 'C formed worker does not implement class reminder side effects');

    // D. Two workers same 2-person session -> only one cancellation and one side-effect set.
    await createSession({ id: 7401 });
    await seedConfirmed(7401, [3008,3009]);
    const d1 = makeWorker('2026-09-10T10:00:00.000Z').worker;
    const d2 = makeWorker('2026-09-10T10:00:00.000Z').worker;
    const dRace = await Promise.all([d1.processSession(7401), d2.processSession(7401)]);
    const dSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=7401`);
    assertCheck(dRace.every(x => ['cancelled','noop'].includes(x.outcome)), 'D two workers serialize safely on same 2-person session');
    assertCheck(dSession.lifecycle_status === 'cancelled' && dSession.formation_status === 'failed' && dSession.booked_count === 0, 'D two workers converge to one failed cancellation');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7401' AND action='session_cancelled_insufficient_students'`) === 1, 'D concurrent workers do not duplicate cancellation log');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=7401 AND type='insufficient_students_cancelled'`) === 6, 'D concurrent workers do not duplicate cancellation outbox');

    // E. Two workers same 3-person session -> formed once/log once.
    await createSession({ id: 7501 });
    await seedConfirmed(7501, [3010,3011,3012]);
    const eRace = await Promise.all([
      makeWorker('2026-09-10T10:00:00.000Z').worker.processSession(7501),
      makeWorker('2026-09-10T10:00:00.000Z').worker.processSession(7501)
    ]);
    const eSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=7501`);
    assertCheck(eRace.every(x => ['formed','noop'].includes(x.outcome)), 'E two workers serialize safely on same 3-person session');
    assertCheck(eSession.lifecycle_status === 'open' && eSession.formation_status === 'formed' && eSession.booked_count === 3, 'E concurrent workers converge to formed once');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7501' AND action='formation_formed'`) === 1, 'E concurrent workers write formation log once');

    // F. Worker vs third booking at T-60 with authoritative 2 -> third cannot rescue.
    await createSession({ id: 7601 });
    await seedConfirmed(7601, [3013,3014]);
    const fWorker = makeWorker('2026-09-10T10:00:00.000Z').worker;
    const fBooking = makeStudentStack('2026-09-10T10:00:00.000Z').bookingService;
    const fRace = await Promise.allSettled([
      fWorker.processSession(7601),
      fBooking.createBooking({ authContext: auth(3015), sessionId: 7601, idempotencyKey: 'phase1e-f-third' })
    ]);
    const fSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=7601`);
    assertCheck(fRace[0].status === 'fulfilled' && fRace[1].status === 'rejected' && fRace[1].reason.code === 'SESSION_CANCELLED', 'F worker vs third booking rejects third learner as SESSION_CANCELLED');
    assertCheck(fSession.lifecycle_status === 'cancelled' && fSession.formation_status === 'failed' && fSession.booked_count === 0, 'F worker vs third booking preserves T-60 two-person authoritative failure');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=7601 AND user_id=3015`) === 0, 'F third learner never creates a booking row');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7601' AND action='session_cancelled_insufficient_students'`) === 1, 'F worker/booking race writes insufficient cancellation once');

    // G. Worker vs learner cancellation on pending 3 at T-60 -> serial formation then 3->2 cancellation.
    await createSession({ id: 7701 });
    const gBookings = await seedConfirmed(7701, [3016,3017,3018]);
    const gWorker = makeWorker('2026-09-10T10:00:00.000Z').worker;
    const gCancel = makeStudentStack('2026-09-10T10:00:00.000Z').cancellationService;
    const gRace = await Promise.allSettled([
      gWorker.processSession(7701),
      gCancel.cancelBooking({ authContext: auth(3016), bookingId: gBookings[0], idempotencyKey: 'phase1e-g-cancel' })
    ]);
    const gSession = await row(pool, `SELECT lifecycle_status, formation_status, booked_count FROM class_sessions WHERE id=7701`);
    assertCheck(gRace.every(x => x.status === 'fulfilled'), 'G worker and learner cancellation both complete under session-first serialization');
    assertCheck(gSession.lifecycle_status === 'cancelled' && gSession.formation_status === 'failed' && gSession.booked_count === 0, 'G worker/cancellation race converges to cancelled+failed with zero count');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=7701 AND status='cancelled'`) === 1 && await count(pool, `SELECT COUNT(*) c FROM bookings WHERE session_id=7701 AND status='system_cancelled'`) === 2, 'G initiating learner remains cancelled and remaining two are system_cancelled');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7701' AND action='formation_formed'`) === 1 && await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7701' AND action='session_cancelled_insufficient_students'`) === 1, 'G worker/cancellation race does not duplicate formation or cancellation logs');

    // H. Rerun an already formed session -> no-op/log unchanged.
    await createSession({ id: 7801 });
    await seedConfirmed(7801, [3019,3020,3021]);
    const hWorker = makeWorker('2026-09-10T10:00:00.000Z').worker;
    const hFirst = await hWorker.processSession(7801);
    const hSecond = await hWorker.processSession(7801);
    assertCheck(hFirst.outcome === 'formed' && hSecond.outcome === 'noop', 'H rerunning already formed session is a no-op');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7801' AND action='formation_formed'`) === 1, 'H rerun formed session does not duplicate formation log');

    // I. Rerun failed/cancelled -> no-op/outbox/log unchanged.
    await createSession({ id: 7901 });
    await seedConfirmed(7901, [3022,3023]);
    const iWorker = makeWorker('2026-09-10T10:00:00.000Z').worker;
    const iFirst = await iWorker.processSession(7901);
    const iNotifications = await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=7901`);
    const iLogs = await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7901' AND action='session_cancelled_insufficient_students'`);
    const iSecond = await iWorker.processSession(7901);
    assertCheck(iFirst.outcome === 'cancelled' && iSecond.outcome === 'noop', 'I rerunning failed/cancelled session is a no-op');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=7901`) === iNotifications && await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='7901' AND action='session_cancelled_insufficient_students'`) === iLogs, 'I failed/cancelled retry does not duplicate outbox or log');

    // J. Delayed in_progress + pending -> authoritative delayed Formation still completes.
    await createSession({ id: 8001, lifecycle: 'in_progress' });
    await seedConfirmed(8001, [3024,3025,3026]);
    const jResult = await makeWorker('2026-09-10T11:05:00.000Z').worker.processSession(8001);
    const jSession = await row(pool, `SELECT lifecycle_status, formation_status, formation_decided_at FROM class_sessions WHERE id=8001`);
    assertCheck(jResult.outcome === 'formed' && jSession.lifecycle_status === 'in_progress' && jSession.formation_status === 'formed' && jSession.formation_decided_at !== null, 'J delayed in_progress+pending completes authoritative Formation');

    // K. Delayed finished + pending -> authoritative delayed Formation still completes.
    await createSession({ id: 8101, lifecycle: 'finished' });
    await seedConfirmed(8101, [3027,3028,3029]);
    const kResult = await makeWorker('2026-09-10T12:00:00.000Z').worker.processSession(8101);
    const kSession = await row(pool, `SELECT lifecycle_status, formation_status, formation_decided_at FROM class_sessions WHERE id=8101`);
    assertCheck(kResult.outcome === 'formed' && kSession.lifecycle_status === 'finished' && kSession.formation_status === 'formed' && kSession.formation_decided_at !== null, 'K delayed finished+pending completes authoritative Formation');

    // L. Cancelled + pending/admin_cancelled retry -> no Formation side effects.
    await createSession({ id: 8201, lifecycle: 'cancelled', formation: 'pending', cancelReason: 'admin_cancelled', cancelledAt: '2026-09-10T09:30:00.000Z' });
    await seedConfirmed(8201, [3030,3031,3032]);
    const lBeforeLogs = await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='8201'`);
    const lBeforeNotifications = await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=8201`);
    const lResult = await makeWorker('2026-09-10T10:05:00.000Z').worker.processSession(8201);
    const lSession = await row(pool, `SELECT lifecycle_status, formation_status, cancel_reason, booked_count FROM class_sessions WHERE id=8201`);
    assertCheck(lResult.outcome === 'noop' && lSession.lifecycle_status === 'cancelled' && lSession.formation_status === 'pending' && lSession.cancel_reason === 'admin_cancelled', 'L cancelled+pending/admin_cancelled is authoritative no-op');
    assertCheck(await count(pool, `SELECT COUNT(*) c FROM operation_logs WHERE entity_id='8201'`) === lBeforeLogs && await count(pool, `SELECT COUNT(*) c FROM notifications WHERE session_id=8201`) === lBeforeNotifications, 'L cancelled+pending retry creates no formation logs or outbox');

    console.log(`SUMMARY | pass=${passCount} fail=${failCount}`);
    if (failCount > 0) process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error('FATAL', error && error.stack ? error.stack : error);
  process.exitCode = 1;
});
