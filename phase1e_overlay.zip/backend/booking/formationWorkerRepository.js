'use strict';

const { BookingRepository } = require('./bookingRepository');

function allRows(result) {
  const rows = Array.isArray(result) ? result[0] : result;
  return Array.isArray(rows) ? rows : [];
}

class FormationWorkerRepository extends BookingRepository {
  async findDueOpenPendingSessionIds({ now, batchSize }) {
    if (!(now instanceof Date) || !Number.isFinite(now.getTime())) {
      throw new TypeError('now must be a valid Date');
    }
    if (!Number.isInteger(batchSize) || batchSize < 1 || batchSize > 1000) {
      throw new RangeError('batchSize must be an integer between 1 and 1000');
    }

    // Candidate discovery is intentionally non-locking. The result is only a hint;
    // processSession() must re-lock and re-check every business condition.
    const result = await this.pool.execute(
      `SELECT id
       FROM class_sessions
       WHERE lifecycle_status = 'open'
         AND formation_status = 'pending'
         AND formation_check_at <= ?
       ORDER BY formation_check_at ASC, id ASC
       LIMIT ${batchSize}`,
      [now]
    );
    return allRows(result).map((row) => row.id);
  }
}

module.exports = Object.freeze({ FormationWorkerRepository });
