'use strict';

const {
  BOOKING_STATUS,
  NOTIFICATION_DELIVERY_STATUS
} = require('../domain/constants');
const { BookingRepository } = require('./bookingRepository');

function firstRow(result) {
  const rows = Array.isArray(result) ? result[0] : result;
  return Array.isArray(rows) && rows.length ? rows[0] : null;
}

function allRows(result) {
  const rows = Array.isArray(result) ? result[0] : result;
  return Array.isArray(rows) ? rows : [];
}

function isDuplicateEntry(error) {
  return error && (error.code === 'ER_DUP_ENTRY' || error.errno === 1062);
}

class ClassReminderRepository extends BookingRepository {
  async findDueReminderCandidateSessionIds({ now, batchSize }) {
    if (!(now instanceof Date) || !Number.isFinite(now.getTime())) {
      throw new TypeError('now must be a valid Date');
    }
    if (!Number.isInteger(batchSize) || batchSize < 1 || batchSize > 1000) {
      throw new RangeError('batchSize must be an integer between 1 and 1000');
    }

    // Candidate discovery is intentionally non-locking. It may be stale by the time
    // processSession() runs, so every business condition is re-checked under the
    // class_session row lock.
    const result = await this.pool.execute(
      `SELECT id
       FROM class_sessions
       WHERE lifecycle_status = 'open'
         AND formation_status IN ('pending','formed','not_required')
         AND formation_check_at <= ?
         AND start_at > ?
       ORDER BY formation_check_at ASC, id ASC
       LIMIT ${batchSize}`,
      [now, now]
    );
    return allRows(result).map((row) => row.id);
  }

  async lockEligibleReminderBookings(sessionId, formationCheckAt, connection) {
    return allRows(await connection.execute(
      `SELECT id, user_id, created_at
       FROM bookings
       WHERE session_id = ?
         AND status = ?
         AND created_at <= ?
       ORDER BY id ASC
       FOR UPDATE`,
      [sessionId, BOOKING_STATUS.CONFIRMED, formationCheckAt]
    ));
  }

  async getReminderPresentation(sessionId, connection) {
    return firstRow(await connection.execute(
      `SELECT
         s.id AS session_id,
         c.name AS course_name,
         t.name AS teacher_name,
         cr.name AS classroom_name,
         cr.campus_name AS campus_name
       FROM class_sessions s
       JOIN courses c ON c.id = s.course_id
       JOIN teachers t ON t.id = s.teacher_id
       JOIN classrooms cr ON cr.id = s.classroom_id
       WHERE s.id = ?
       LIMIT 1`,
      [sessionId]
    ));
  }

  async insertClassReminderNotification({ userId, sessionId, type, channel, payload, dedupeKey }, connection) {
    try {
      const [result] = await connection.execute(
        `INSERT INTO notifications
           (user_id, session_id, type, channel, delivery_status, payload, dedupe_key)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          userId,
          sessionId,
          type,
          channel,
          NOTIFICATION_DELIVERY_STATUS.PENDING,
          JSON.stringify(payload),
          dedupeKey
        ]
      );
      return Object.freeze({ created: true, id: result.insertId });
    } catch (error) {
      if (!isDuplicateEntry(error)) throw error;
      // notifications.dedupe_key UNIQUE is the final cross-process protection.
      const existing = firstRow(await connection.execute(
        `SELECT id
         FROM notifications
         WHERE dedupe_key = ?
         LIMIT 1`,
        [dedupeKey]
      ));
      return Object.freeze({ created: false, id: existing ? existing.id : null });
    }
  }
}

module.exports = Object.freeze({ ClassReminderRepository });
