'use strict';

const { withTransaction } = require('../db/pool');
const {
  CLASS_TYPE,
  LIFECYCLE_STATUS,
  FORMATION_STATUS,
  NOTIFICATION_CHANNEL,
  NOTIFICATION_TYPE,
  OPERATION_ACTOR_TYPE
} = require('../domain/constants');

const DEFAULT_BATCH_SIZE = 100;
const MAX_BATCH_SIZE = 1000;

function toDate(value, fieldName = 'now') {
  const date = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(date.getTime())) throw new TypeError(`${fieldName} must be a valid instant`);
  return date;
}

function toIso(value) {
  return toDate(value).toISOString();
}

function normalizeBatchSize(value) {
  const batchSize = value === undefined || value === null ? DEFAULT_BATCH_SIZE : Number(value);
  if (!Number.isInteger(batchSize) || batchSize < 1 || batchSize > MAX_BATCH_SIZE) {
    throw new RangeError(`batchSize must be an integer between 1 and ${MAX_BATCH_SIZE}`);
  }
  return batchSize;
}

function sessionSnapshot(session) {
  if (!session) return null;
  return Object.freeze({
    id: String(session.id),
    lifecycle_status: session.lifecycle_status,
    formation_status: session.formation_status,
    booked_count: Number(session.booked_count),
    formation_decided_at: session.formation_decided_at || null,
    cancel_reason: session.cancel_reason === undefined ? null : session.cancel_reason,
    cancelled_at: session.cancelled_at || null
  });
}

function uniqueRecipientIds(ids) {
  const seen = new Set();
  const result = [];
  for (const raw of ids) {
    if (raw === null || raw === undefined) continue;
    const key = String(raw);
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(raw);
  }
  return result;
}

class ClassReminderWorker {
  constructor({
    repository,
    formationService,
    now = () => new Date(),
    transactionRunner = withTransaction,
    batchSize = DEFAULT_BATCH_SIZE
  }) {
    if (!repository || !repository.pool) throw new TypeError('repository.pool is required');
    if (!formationService || typeof formationService.ensureFormationDecision !== 'function') {
      throw new TypeError('formationService.ensureFormationDecision is required');
    }
    if (typeof now !== 'function') throw new TypeError('now must be a function');
    if (typeof transactionRunner !== 'function') throw new TypeError('transactionRunner must be a function');

    this.repository = repository;
    this.formationService = formationService;
    this.now = now;
    this.transactionRunner = transactionRunner;
    this.batchSize = normalizeBatchSize(batchSize);
  }

  async processSession(sessionId, { now = null } = {}) {
    const reminderNow = toDate(now === null ? this.now() : now);

    return this.transactionRunner(this.repository.pool, async (connection) => {
      let session = await this.repository.lockSession(sessionId, connection);
      if (!session) {
        return Object.freeze({ sessionId: String(sessionId), outcome: 'missing', createdDeliveries: 0, session: null });
      }

      // Reminder has a stricter lifecycle window than delayed Formation. Once a class
      // has started/finished, a stale retry must not send an "upcoming class" reminder.
      if (session.lifecycle_status !== LIFECYCLE_STATUS.OPEN) {
        return Object.freeze({
          sessionId: String(session.id),
          outcome: 'noop',
          createdDeliveries: 0,
          session: sessionSnapshot(session)
        });
      }

      const formationCheckAt = toDate(session.formation_check_at, 'formation_check_at');
      const startAt = toDate(session.start_at, 'start_at');
      if (reminderNow.getTime() < formationCheckAt.getTime() || reminderNow.getTime() >= startAt.getTime()) {
        return Object.freeze({
          sessionId: String(session.id),
          outcome: 'noop',
          createdDeliveries: 0,
          session: sessionSnapshot(session)
        });
      }

      const isPrivate = session.class_type_code === CLASS_TYPE.PRIVATE.code;
      if (session.formation_status === FORMATION_STATUS.PENDING) {
        // Group sessions must always settle Formation before reminder generation.
        // Private sessions reuse FormationService only for its frozen pending ->
        // not_required normalization; no three-person Formation rule is introduced.
        const decision = await this.formationService.ensureFormationDecision({
          connection,
          session,
          now: reminderNow
        });
        session = decision.session;
      }

      if (session.lifecycle_status !== LIFECYCLE_STATUS.OPEN) {
        return Object.freeze({
          sessionId: String(session.id),
          outcome: 'formation_cancelled',
          createdDeliveries: 0,
          session: sessionSnapshot(session)
        });
      }

      if (isPrivate) {
        if (session.formation_status !== FORMATION_STATUS.NOT_REQUIRED) {
          return Object.freeze({ sessionId: String(session.id), outcome: 'noop', createdDeliveries: 0, session: sessionSnapshot(session) });
        }
      } else if (session.formation_status !== FORMATION_STATUS.FORMED) {
        return Object.freeze({ sessionId: String(session.id), outcome: 'noop', createdDeliveries: 0, session: sessionSnapshot(session) });
      }

      // Current confirmed state AND booking existed at/before the T-60 boundary.
      // This explicitly prevents retroactive reminders for T-60+ bookings.
      const eligibleBookings = await this.repository.lockEligibleReminderBookings(
        session.id,
        session.formation_check_at,
        connection
      );

      // A private lesson only exists for reminder purposes when an eligible current
      // confirmed booking exists. No booking means neither learner nor teacher reminder.
      if (isPrivate && eligibleBookings.length === 0) {
        return Object.freeze({
          sessionId: String(session.id),
          outcome: 'noop',
          createdDeliveries: 0,
          eligibleStudentCount: 0,
          session: sessionSnapshot(session)
        });
      }

      const studentRecipientIds = eligibleBookings.map((booking) => booking.user_id);
      const recipientIds = uniqueRecipientIds([
        ...studentRecipientIds,
        session.teacher_user_id
      ]);
      if (recipientIds.length === 0) {
        return Object.freeze({ sessionId: String(session.id), outcome: 'noop', createdDeliveries: 0, session: sessionSnapshot(session) });
      }

      const presentation = await this.repository.getReminderPresentation(session.id, connection);
      const payload = Object.freeze({
        session_id: String(session.id),
        course_name: presentation && presentation.course_name ? presentation.course_name : session.course_name,
        start_at: toIso(session.start_at),
        end_at: toIso(session.end_at),
        teacher_name: presentation && presentation.teacher_name ? presentation.teacher_name : null,
        classroom_name: presentation && presentation.classroom_name ? presentation.classroom_name : null,
        campus_name: presentation && presentation.campus_name ? presentation.campus_name : null
      });

      let createdDeliveries = 0;
      for (const recipientUserId of recipientIds) {
        for (const channel of [NOTIFICATION_CHANNEL.IN_APP, NOTIFICATION_CHANNEL.WECHAT_SUBSCRIBE]) {
          const inserted = await this.repository.insertClassReminderNotification({
            userId: recipientUserId,
            sessionId: session.id,
            type: NOTIFICATION_TYPE.CLASS_REMINDER,
            channel,
            payload,
            dedupeKey: `class_reminder:${session.id}:${recipientUserId}:${channel}`
          }, connection);
          if (inserted.created) createdDeliveries += 1;
        }
      }

      // No schema field is added for reminder audit dedupe. Because every reminder
      // writer locks the session first and notifications have a unique dedupe key,
      // only the transaction that creates at least one delivery may create the audit.
      if (createdDeliveries > 0) {
        await this.repository.insertOperationLog({
          actorType: OPERATION_ACTOR_TYPE.SYSTEM,
          action: 'class_reminder_generated',
          entityType: 'class_session',
          entityId: session.id,
          before: null,
          after: {
            eligible_student_count: studentRecipientIds.length,
            recipient_count: recipientIds.length,
            delivery_count: createdDeliveries
          },
          reason: null
        }, connection);
      }

      return Object.freeze({
        sessionId: String(session.id),
        outcome: createdDeliveries > 0 ? 'generated' : 'noop',
        createdDeliveries,
        eligibleStudentCount: studentRecipientIds.length,
        recipientCount: recipientIds.length,
        session: sessionSnapshot(session)
      });
    });
  }

  async runOnce({ batchSize = this.batchSize } = {}) {
    const normalizedBatchSize = normalizeBatchSize(batchSize);
    const scanNow = toDate(this.now());
    const candidateIds = await this.repository.findDueReminderCandidateSessionIds({
      now: scanNow,
      batchSize: normalizedBatchSize
    });

    const results = [];
    for (const sessionId of candidateIds) {
      try {
        results.push(await this.processSession(sessionId));
      } catch (error) {
        results.push(Object.freeze({
          sessionId: String(sessionId),
          outcome: 'error',
          error: Object.freeze({
            code: error && error.code ? String(error.code) : 'CLASS_REMINDER_WORKER_ERROR',
            message: error && error.message ? String(error.message) : 'Unknown class reminder worker error'
          })
        }));
      }
    }

    const summary = results.reduce((acc, item) => {
      acc[item.outcome] = (acc[item.outcome] || 0) + 1;
      return acc;
    }, {});
    return Object.freeze({
      scannedAt: scanNow.toISOString(),
      batchSize: normalizedBatchSize,
      candidateCount: candidateIds.length,
      generatedCount: summary.generated || 0,
      formationCancelledCount: summary.formation_cancelled || 0,
      noopCount: summary.noop || 0,
      missingCount: summary.missing || 0,
      errorCount: summary.error || 0,
      createdDeliveries: results.reduce((sum, item) => sum + Number(item.createdDeliveries || 0), 0),
      results: Object.freeze(results)
    });
  }
}

module.exports = Object.freeze({
  DEFAULT_BATCH_SIZE,
  MAX_BATCH_SIZE,
  ClassReminderWorker,
  normalizeBatchSize
});
