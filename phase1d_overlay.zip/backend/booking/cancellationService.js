'use strict';

const crypto = require('node:crypto');
const { withTransaction } = require('../db/pool');
const {
  BOOKING_STATUS,
  CLASS_TYPE,
  LIFECYCLE_STATUS,
  FORMATION_STATUS,
  NOTIFICATION_CHANNEL,
  NOTIFICATION_TYPE,
  OPERATION_ACTOR_TYPE,
  ERROR_CODE
} = require('../domain/constants');
const { reconcileLifecycleStatus } = require('../domain/sessionRules');
const { bookingError } = require('./errors');
const { forbidden } = require('../auth/errors');

const CANCELLATION_IDEMPOTENCY_SCOPE = 'POST /bookings/:id/cancel';
const CANCELLATION_IDEMPOTENCY_TTL_MS = 24 * 60 * 60 * 1000;

function toDate(value) {
  return value instanceof Date ? value : new Date(value);
}

function toIsoOrNull(value) {
  return value === null || value === undefined ? null : toDate(value).toISOString();
}

function normalizeStoredJson(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === 'string') return JSON.parse(value);
  return value;
}

function cancellationRequestHash(bookingId) {
  return crypto.createHash('sha256')
    .update(JSON.stringify({ booking_id: String(bookingId) }), 'utf8')
    .digest('hex');
}

function cancellationPayload({ booking, session }) {
  return Object.freeze({
    booking: Object.freeze({
      id: String(booking.id),
      session_id: String(booking.session_id),
      user_id: String(booking.user_id),
      status: booking.status,
      cancelled_at: toIsoOrNull(booking.cancelled_at),
      cancel_reason: booking.cancel_reason === undefined ? null : booking.cancel_reason
    }),
    session: Object.freeze({
      id: String(session.id),
      lifecycle_status: session.lifecycle_status,
      formation_status: session.formation_status,
      booked_count: Number(session.booked_count),
      min_students: Number(session.min_students),
      capacity: Number(session.capacity),
      start_at: toIsoOrNull(session.start_at),
      end_at: toIsoOrNull(session.end_at),
      formation_check_at: toIsoOrNull(session.formation_check_at),
      cancel_lock_at: toIsoOrNull(session.cancel_lock_at),
      cancel_reason: session.cancel_reason === undefined ? null : session.cancel_reason,
      cancelled_at: toIsoOrNull(session.cancelled_at)
    })
  });
}

class CancellationService {
  constructor({ repository, formationService, now = () => new Date(), transactionRunner = withTransaction }) {
    this.repository = repository;
    this.formationService = formationService;
    this.now = now;
    this.transactionRunner = transactionRunner;
  }

  async cancelBooking({ authContext, bookingId, idempotencyKey = null }) {
    if (!authContext || !authContext.user) throw new TypeError('authContext is required');
    const userId = authContext.user.id;
    const now = toDate(this.now());
    const normalizedKey = idempotencyKey === null || idempotencyKey === undefined || idempotencyKey === ''
      ? null
      : String(idempotencyKey);
    if (normalizedKey && normalizedKey.length > 128) {
      throw bookingError(ERROR_CODE.IDEMPOTENCY_CONFLICT, 'Idempotency key is too long');
    }

    // Locator query is intentionally non-locking. It exists only to discover the
    // session row that must be the first business lock in the transaction.
    const locator = await this.repository.findBookingLocator(bookingId);
    if (!locator) throw forbidden('Booking is unavailable');
    if (String(locator.user_id) !== String(userId)) throw forbidden('Booking does not belong to current user');

    const requestHash = cancellationRequestHash(bookingId);
    return this.transactionRunner(this.repository.pool, async (connection) => {
      // Global lock order for all count-changing flows: session first, booking second.
      let session = await this.repository.lockSession(locator.session_id, connection);
      if (!session) throw forbidden('Booking session is unavailable');

      let booking = await this.repository.lockBooking(bookingId, connection);
      if (!booking) throw forbidden('Booking is unavailable');
      if (
        String(booking.user_id) !== String(userId) ||
        String(booking.session_id) !== String(locator.session_id)
      ) {
        throw forbidden('Booking does not belong to current user');
      }

      if (normalizedKey) {
        const existing = await this.repository.findIdempotencyForUpdate({
          userId,
          scope: CANCELLATION_IDEMPOTENCY_SCOPE,
          key: normalizedKey
        }, connection);
        if (existing) {
          if (existing.request_hash !== requestHash) {
            throw bookingError(ERROR_CODE.IDEMPOTENCY_CONFLICT, 'Idempotency key was already used for another request');
          }
          if (existing.state === 'completed') {
            return Object.freeze({
              status: Number(existing.response_status || 200),
              payload: normalizeStoredJson(existing.response_body),
              idempotentReplay: true
            });
          }
          throw bookingError(ERROR_CODE.IDEMPOTENCY_CONFLICT, 'Idempotent request is still in progress');
        }

        const reservation = await this.repository.reserveIdempotency({
          userId,
          scope: CANCELLATION_IDEMPOTENCY_SCOPE,
          key: normalizedKey,
          requestHash,
          expiresAt: new Date(now.getTime() + CANCELLATION_IDEMPOTENCY_TTL_MS)
        }, connection);
        if (!reservation.created) {
          if (!reservation.record || reservation.record.request_hash !== requestHash) {
            throw bookingError(ERROR_CODE.IDEMPOTENCY_CONFLICT, 'Idempotency key was already used for another request');
          }
          if (reservation.record.state === 'completed') {
            return Object.freeze({
              status: Number(reservation.record.response_status || 200),
              payload: normalizeStoredJson(reservation.record.response_body),
              idempotentReplay: true
            });
          }
          throw bookingError(ERROR_CODE.IDEMPOTENCY_CONFLICT, 'Idempotent request is still in progress');
        }
      }

      const reconciled = reconcileLifecycleStatus({
        lifecycleStatus: session.lifecycle_status,
        now,
        startAt: session.start_at,
        endAt: session.end_at
      });
      if (reconciled !== session.lifecycle_status) {
        await this.repository.updateLifecycleStatus(session.id, reconciled, connection);
        session.lifecycle_status = reconciled;
      }

      // T-60 is an authoritative hard boundary. Formation always happens before
      // the learner's own confirmed booking can be removed from the count.
      if (
        session.formation_status === FORMATION_STATUS.PENDING &&
        now.getTime() >= toDate(session.formation_check_at).getTime()
      ) {
        const decision = await this.formationService.ensureFormationDecision({ connection, session, now });
        session = decision.session;
        booking = await this.repository.lockBooking(bookingId, connection) || booking;
      }

      // If the T-60 decision (or an already-authoritative session state) has system
      // cancelled this booking/session, return that latest state and COMMIT it.
      if (
        session.lifecycle_status === LIFECYCLE_STATUS.CANCELLED ||
        booking.status === BOOKING_STATUS.SYSTEM_CANCELLED ||
        booking.status === BOOKING_STATUS.CANCELLED
      ) {
        const payload = cancellationPayload({ booking, session });
        if (normalizedKey) {
          await this.repository.completeIdempotency({
            userId,
            scope: CANCELLATION_IDEMPOTENCY_SCOPE,
            key: normalizedKey,
            responseStatus: 200,
            responseBody: payload
          }, connection);
        }
        return Object.freeze({ status: 200, payload, idempotentReplay: false });
      }

      // Historical attended/absent rows are authoritative and must never be rewritten
      // by a stale cancellation request. Returning the current state is side-effect free.
      if (booking.status !== BOOKING_STATUS.CONFIRMED) {
        const payload = cancellationPayload({ booking, session });
        if (normalizedKey) {
          await this.repository.completeIdempotency({
            userId,
            scope: CANCELLATION_IDEMPOTENCY_SCOPE,
            key: normalizedKey,
            responseStatus: 200,
            responseBody: payload
          }, connection);
        }
        return Object.freeze({ status: 200, payload, idempotentReplay: false });
      }

      if (now.getTime() >= toDate(session.cancel_lock_at).getTime()) {
        throw bookingError(ERROR_CODE.CANCEL_WINDOW_CLOSED, 'Cancellation window is closed');
      }

      const cancelled = await this.repository.cancelConfirmedBooking({
        bookingId: booking.id,
        userId,
        cancelledAt: now
      }, connection);
      if (!cancelled) {
        booking = await this.repository.lockBooking(booking.id, connection) || booking;
        const payload = cancellationPayload({ booking, session });
        if (normalizedKey) {
          await this.repository.completeIdempotency({
            userId,
            scope: CANCELLATION_IDEMPOTENCY_SCOPE,
            key: normalizedKey,
            responseStatus: 200,
            responseBody: payload
          }, connection);
        }
        return Object.freeze({ status: 200, payload, idempotentReplay: false });
      }

      booking.status = BOOKING_STATUS.CANCELLED;
      booking.cancelled_at = now;
      booking.cancel_reason = null;
      booking.operator_user_id = null;

      const confirmedCount = await this.repository.countConfirmedBookings(session.id, connection);
      await this.repository.setBookedCount(session.id, confirmedCount, connection);
      session.booked_count = confirmedCount;

      await this.repository.insertOperationLog({
        actorType: OPERATION_ACTOR_TYPE.USER,
        operatorUserId: userId,
        action: 'booking_cancelled_by_student',
        entityType: 'booking',
        entityId: booking.id,
        before: { status: BOOKING_STATUS.CONFIRMED },
        after: { status: BOOKING_STATUS.CANCELLED, cancelled_at: now.toISOString() },
        reason: null
      }, connection);

      const isGroup = session.class_type_code !== CLASS_TYPE.PRIVATE.code;
      const inFormationProtectionWindow =
        now.getTime() >= toDate(session.formation_check_at).getTime() &&
        now.getTime() < toDate(session.cancel_lock_at).getTime();

      if (
        isGroup &&
        session.formation_status === FORMATION_STATUS.FORMED &&
        inFormationProtectionWindow &&
        confirmedCount < Number(session.min_students)
      ) {
        const before = {
          lifecycle_status: session.lifecycle_status,
          formation_status: session.formation_status,
          booked_count: confirmedCount
        };
        const transitioned = await this.repository.cancelFormedSessionForInsufficientStudents(session.id, now, connection);
        if (!transitioned) {
          const authoritative = await this.repository.lockSession(session.id, connection);
          if (!authoritative || authoritative.lifecycle_status !== LIFECYCLE_STATUS.CANCELLED) {
            throw new Error('INSUFFICIENT_CANCELLATION_TRANSITION_CONFLICT');
          }
          session = authoritative;
        } else {
          const affectedBookings = await this.repository.lockConfirmedBookings(session.id, connection);
          await this.repository.markConfirmedBookingsSystemCancelled(session.id, now, connection);

          const notificationPayload = Object.freeze({
            session_id: String(session.id),
            course_name: session.course_name,
            start_at: toDate(session.start_at).toISOString(),
            end_at: toDate(session.end_at).toISOString(),
            cancel_reason: 'insufficient_students'
          });
          for (const affected of affectedBookings) {
            for (const channel of [NOTIFICATION_CHANNEL.IN_APP, NOTIFICATION_CHANNEL.WECHAT_SUBSCRIBE]) {
              await this.repository.insertNotification({
                userId: affected.user_id,
                sessionId: session.id,
                type: NOTIFICATION_TYPE.INSUFFICIENT_STUDENTS_CANCELLED,
                channel,
                payload: notificationPayload,
                dedupeKey: `insufficient_students_cancelled:${session.id}:student:${affected.user_id}:${channel}`
              }, connection);
            }
          }
          if (session.teacher_user_id !== null && session.teacher_user_id !== undefined) {
            for (const channel of [NOTIFICATION_CHANNEL.IN_APP, NOTIFICATION_CHANNEL.WECHAT_SUBSCRIBE]) {
              await this.repository.insertNotification({
                userId: session.teacher_user_id,
                sessionId: session.id,
                type: NOTIFICATION_TYPE.INSUFFICIENT_STUDENTS_CANCELLED,
                channel,
                payload: notificationPayload,
                dedupeKey: `insufficient_students_cancelled:${session.id}:teacher:${session.teacher_user_id}:${channel}`
              }, connection);
            }
          }
          await this.repository.insertOperationLog({
            actorType: OPERATION_ACTOR_TYPE.SYSTEM,
            action: 'session_cancelled_insufficient_students',
            entityType: 'class_session',
            entityId: session.id,
            before,
            after: {
              lifecycle_status: LIFECYCLE_STATUS.CANCELLED,
              formation_status: FORMATION_STATUS.FAILED,
              booked_count: 0,
              cancel_reason: 'insufficient_students'
            },
            reason: 'insufficient_students'
          }, connection);

          session.lifecycle_status = LIFECYCLE_STATUS.CANCELLED;
          session.formation_status = FORMATION_STATUS.FAILED;
          session.formation_decided_at = now;
          session.cancel_reason = 'insufficient_students';
          session.cancelled_at = now;
          session.booked_count = 0;
        }
      }

      const payload = cancellationPayload({ booking, session });
      if (normalizedKey) {
        await this.repository.completeIdempotency({
          userId,
          scope: CANCELLATION_IDEMPOTENCY_SCOPE,
          key: normalizedKey,
          responseStatus: 200,
          responseBody: payload
        }, connection);
      }
      return Object.freeze({ status: 200, payload, idempotentReplay: false });
    });
  }
}

module.exports = Object.freeze({
  CancellationService,
  CANCELLATION_IDEMPOTENCY_SCOPE,
  CANCELLATION_IDEMPOTENCY_TTL_MS,
  cancellationRequestHash,
  cancellationPayload
});
