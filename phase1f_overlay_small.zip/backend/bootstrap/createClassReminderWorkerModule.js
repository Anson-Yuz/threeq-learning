'use strict';

const { createDatabasePool } = require('../db/pool');
const { ClassReminderRepository } = require('../booking/classReminderRepository');
const { FormationService } = require('../booking/formationService');
const { ClassReminderWorker } = require('../jobs/classReminderWorker');
const { ClassReminderJob } = require('../jobs/classReminderJob');

function createClassReminderWorkerModule({
  env = process.env,
  pool = null,
  nowDate = () => new Date(),
  batchSize = undefined
} = {}) {
  const databasePool = pool || createDatabasePool({ env });
  const repository = new ClassReminderRepository({ pool: databasePool });
  const formationService = new FormationService({ repository });
  const worker = new ClassReminderWorker({
    repository,
    formationService,
    now: nowDate,
    ...(batchSize === undefined ? {} : { batchSize })
  });
  const job = new ClassReminderJob({ worker });

  return Object.freeze({
    pool: databasePool,
    classReminderRepository: repository,
    formationService,
    classReminderWorker: worker,
    classReminderJob: job
  });
}

module.exports = Object.freeze({ createClassReminderWorkerModule });
