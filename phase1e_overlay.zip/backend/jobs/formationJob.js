'use strict';

class FormationJob {
  constructor({ worker }) {
    if (!worker || typeof worker.runOnce !== 'function') throw new TypeError('worker.runOnce is required');
    this.worker = worker;
  }

  async runOnce(options = {}) {
    return this.worker.runOnce(options);
  }
}

module.exports = Object.freeze({ FormationJob });
